package com.mygdx.game;

import java.awt.RenderingHints.Key;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

import screens.GameScreen;
import screens.MenuScreen;

public class ShotGame extends Game {
	GameScreen gameScreen;
	MenuScreen menuScreen;
	public SpriteBatch batch;
	@Override
	public void create () {
		gameScreen = new GameScreen();
		menuScreen = new MenuScreen();
		batch = new SpriteBatch();
		this.setScreen(menuScreen);
	}
	@Override
	public void render () {
		if(Gdx.input.isKeyPressed(Keys.A))
		this.setScreen(gameScreen);
		if(Gdx.input.isKeyPressed(Keys.ESCAPE))
		gameScreen.pause();
		super.render();
		
	}
	@Override
	public void resize(int width, int height) {
		this.screen.resize(width, height);
	}
	@Override
	public void dispose () {
//		gameScreen.dispose();
		super.dispose();
	}
}
