package ships;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

import screens.GameScreen;

public class PlayerShip extends Ship {
	public int lives;
	
	public PlayerShip(float movementSpeed, int shield,
			float xCenter, float yCenter,
			float width, float height,
			float laserWidth, float laserHeight, float laserMovementSpeed,
			float timeBetweenShots,
			TextureRegion shipTexureRegion, TextureRegion shieldTextureRegion,
			TextureRegion laserTextureRegion) {
		super(movementSpeed, shield,
				xCenter, yCenter,
				width, height,
				laserWidth, laserHeight, laserMovementSpeed,
				timeBetweenShots,
				shipTexureRegion, shieldTextureRegion,
				laserTextureRegion);
		lives = 3;
	}



	@Override
	public void update(float deltaTime) {
		super.update(deltaTime);
	}


	@Override
	public Laser[] fireLasers() {
		Laser[] laser = new Laser[1];
		laser[0] = new Laser(xPosition+ 0.42f*width,yPosition + height ,
				laserWidth, laserHeight, 
				laserMovementSpeed, laserTextureRegion);

		timeSinceLastShot = 0;

		return laser;
	}

}
